<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Post extends Authenticatable
{
   
    protected $table = 'posts';

   


    public function show_post(){
         $post=$this->get();
          return $post;
    }

    public function post_id($id){
        $post=$this->where(['id'=>$id])->first();
        return $post;
    }

    public function deletePosts($id){
        $post=$this->where(['id'=>$id])->delete();
        return $post;
    }

    public function show_post_slug($id){
        $post=$this->where(['slug'=>$id])->get();
        return $post;
    }
}
