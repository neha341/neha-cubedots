<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Category extends Authenticatable
{
   
    protected $table = 'category';

    public function show_cat(){
        $post=$this->get();
        return $post;
    } 

    public function cat_id($id){
        $post=$this->where(['id'=>$id])->first();
        return $post;
    } 

    public function deleteCat($id){
    	$post=$this->where(['id'=>$id])->delete();
    	return $post;
    }

     
}
