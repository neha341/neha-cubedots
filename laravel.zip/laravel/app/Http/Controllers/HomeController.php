<?php

namespace App\Http\Controllers;
use App\Http\Controllers\HomeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB;
use App\Http\Requests;
use Session;
use Validator;
use View;
use URL;
use App\User;

class HomeController extends Controller
{
 

   protected $post;
  public function __construct(Request $request)
    {
         
       $this->post= new \App\Models\User();
       $this->postdetails= new \App\Models\Post();
       $this->cat= new \App\Models\Category();
       
    }
 

    public function logout(){
        Session::flush();
        return redirect('/');
    }

    public function loginfrm(Request $request){
        $this->validate($request,[
                    'email'=>'required',
                    'password'=>'required', 
                    'type' =>'required',  
          ],[
            'email'=>"Email Field is required",
            'password'=>"Password Field is required",
            'type'=>'Type Field is required',
          ]);
    	  $email=$request->input('email');
    	  $password=md5($request->input('password'));
          $type=$request->input('type');


           $login=$this->post->login($email,$password,$type);

    	   if(count($login)>0){

            if($type=='super_admin'){
    	  	$request->session()->put('Adminnewlogin',array('id'=>$login[0]['id'],'name'=>$login[0]['name'],'email'=>$login[0]['email']));
            }elseif($type=='editor'){
            $request->session()->put('Editorlogin',array('id'=>$login[0]['id'],'name'=>$login[0]['name'],'email'=>$login[0]['email']));
            }elseif($type=='reader'){
            $request->session()->put('Readerlogin',array('id'=>$login[0]['id'],'name'=>$login[0]['name'],'email'=>$login[0]['email']));
            }
    	  	return redirect('dashboard')->with('messages','Login Done Successfully');
    	  }else{
    	  	return redirect('login')->with('messagerror','Invalid email or password');
    	  }
    	
    }


    public function dashbord(){
        if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
        $post=$this->postdetails->show_post();
        $cat=$this->cat->show_cat();     
        return view('dashbord')->with(['cat'=>$cat,'post'=>$post]);
      }else{
        return redirect('login');
      }
    }




    
    
   

   
  

  
}
?>
