<?php

namespace App\Http\Controllers;
use App\Http\Controllers\HomeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB;
use App\Http\Requests;
use Session;
use Validator;
use View;
use URL;
use App\User;
use App\Post;
class PostController extends Controller
{
 

  protected $post;
  public function __construct(Request $request)
    {
         
       $this->post= new \App\Models\Post();
       $this->cat= new \App\Models\Category();
    }


    public function category(){
       if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
        return view('category/add_cat');
       }else{
        return redirect('login');
       }
    }

    public function addCatFrm(Request $request){
        if(!empty($_POST)){

            $cat_name=$request->input('category_name');
            $this->cat->category_name=$cat_name;
            $save=$this->cat->save();
            if($save){
                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='category Added Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
        }
    }


    public function editCat(Request $request){
       if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
      	$id=$request->post('id');
      	$cat=$this->cat->cat_id($id);
        return view('category/show_cat')->with(['cat'=>$cat]);
       }else{
        return redirect('login');
       }
    }


    public function editPost(Request $request){
    if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
      	$id=$request->post('id');
      	$post=$this->post->post_id($id);
        return view('post/show_post')->with(['post'=>$post]);
       }else{
        return redirect('login');
       }
    }


    public function editCatFrm(Request $request){

    	if(!empty($_POST)){

            $cat_name=$request->post('category_name');
            $id=$request->post('id');
            $cat=$this->cat::find($id);
            $cat->category_name=$cat_name;
            $save=$cat->save();
            if($save){
                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='Category Edit Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
        }
    }


    public function deleteCat(Request $request){
    	if(!empty($_POST)){
    		$id=$request->post('id');
    		$save=$this->cat->deleteCat($id);
    		if($save){
                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='Category Delete Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
    	}
    }


  public function deletePost(Request $request){
  	if(!empty($_POST)){
    		$id=$request->post('id');
    		$save=$this->post->deletePosts($id);
    		if($save){
                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='Post Delete Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
    	}
  }
    public function showPost(){
     if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
	     
	      	$cat=$this->cat->show_cat();
	        return view('post/add_post')->with(['cat'=>$cat]);
	       }else{
	        return redirect('login');
	       }
	    }

	  public function addPostFrm(Request $request){
	  	if(!empty($_POST)){
            $title=$request->post('title');
            $slug=$request->post('slug');
            $description=$request->post('description');
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $name = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/images');
                $image->move($destinationPath, $name);
            }
           if(Session::has('Adminnewlogin')){
           	$value = session('Adminnewlogin');
           }else{
           	$value = session('Editorlogin');
           }
            $this->post->title=$title;
            $this->post->slug=$slug;
            $this->post->description=$description;
            $this->post->featured_image=$name;
            $this->post->user_id=$value['id'];
            $save=$this->post->save();
            if($save){

                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='Post Add Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
        }
	  }
	  public function editPostFrm(Request $request){
	  	if(!empty($_POST)){
            $title=$request->post('edit_title');
            $slug=$request->post('edit_slug');
            $description=$request->post('edit_description');
            if ($request->hasFile('edit_image')) {
                $image = $request->file('edit_image');
                $name = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/images');
                $image->move($destinationPath, $name);
            }else{
            	$name=$request->post('img');
            }
           if(Session::has('Adminnewlogin')){
           	$value = session('Adminnewlogin');
           }else{
           	$value = session('Editorlogin');
           }
           $obj=$this->post::find($request->post('id'));
           $obj->title=$title;
           $obj->slug=$slug;
           $obj->description=$description;
           $obj->featured_image=$name;
           $obj->user_id=$value['id'];
           $save=$obj->save();
            if($save){
                $data['success']=true;
                $data['redirect']=url('dashboard');
                $data['message']='Post Edit Successfully';
             
             }else{
                 $data['success']=false;
                 $data['message']='Something went wrong';
             }
             echo json_encode($data);
        }
	  }


public function postview($slug){
  if(Session::has('Adminnewlogin') || Session::has('Editorlogin') ||Session::has('Readerlogin')){
  	 $post=$this->post->show_post_slug($slug);
  	return view('post.view')->with(['post'=>$post]);
  }
}
	 
}

?>