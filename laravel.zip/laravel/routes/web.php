<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController; 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});
Route::get('login', function () {
    return view('login');
});
Route::post('login','HomeController@loginfrm');
Route::get('welcome','HomeController@index');

Route::get('dashboard','HomeController@dashbord');
Route::get('add_category','PostController@category');
Route::post('add-cat-frm','PostController@addCatFrm');
Route::post('edit_cat','PostController@editCat');
Route::post('edit-cat-frm','PostController@editCatFrm');
Route::post('delete-cat','PostController@deleteCat');
Route::get('add_post','PostController@showPost');
Route::post('add-post-frm','PostController@addPostFrm');
Route::post('edit_post','PostController@editPost');
Route::post('edit-post-frm','PostController@editPostFrm');

Route::post('delete-post','PostController@deletePost');
Route::get('logout','HomeController@logout');
Route::get('post-view/{id}','PostController@postview');