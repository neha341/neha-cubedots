
<?php $__env->startSection('content'); ?>




<div class="container">Welcom <?php if(Session::has('Adminnewlogin')): ?>
<?php echo session('Adminnewlogin')['name']; ?>
<?php elseif(Session::has('Editorlogin')): ?>
<?php echo session('Editorlogin')['name']; ?>
<?php elseif(Session::has('Readerlogin')): ?>
<?php echo session('Readerlogin')['name']; ?>
<?php endif; ?>

 ,
<a href="<?php echo e(url('logout')); ?>"><i class="icon-power mr-2"></i> Logout</a>

<section>
<div class="top-tabs-container">
  <label for="main-tab-1">Category</label>
  <label for="main-tab-2">Post</label>

</div>

<!-- Tab Container -->
<input class="tab-radio" id="main-tab-1" name="main-group" type="radio" checked="checked"/>
<div class="tab-content">
	<?php if(Session::has('Adminnewlogin')): ?><a class="btn btn-info" href="<?php echo e(url('add_category')); ?>">Add Category</a> <?php endif; ?>
  <table class="table">
  <thead>
    <tr>
      <th >#</th>
      <th >Category Name</th>
      <th >Created at</th>
      <th >Updated at</th>
      <th >Action</th>
    </tr>
  </thead>
  <?php if($cat->count()>0): ?>
  <?php $i=0;?>
  <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php  $i++ ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($i); ?></th>
      <td><?php echo e($rows['category_name']); ?></td>
      <td><?php echo e($rows['created_at']); ?></td>
      <td><?php echo e($rows['updated_at']); ?></td>
    
      <td>  <?php if(Session::has('Adminnewlogin') || Session::has('Editorlogin')): ?>
      	<button class="btn btn-info editcategorys" data-id="<?php echo e($rows['id']); ?>" type="button">Edit</button><?php endif; ?>
      	<?php if(Session::has('Adminnewlogin')): ?><button class="btn btn-danger deletecat" data-id="<?php echo e($rows['id']); ?>" type="button">Delete</button><?php endif; ?>

      </td>



    </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</table>
</div>


<!-- EXTRA TABS FOR SHOW & TESTING -->
  
 <!-- Tab Container -->
<input class="tab-radio" id="main-tab-2" name="main-group" type="radio"/>
<div class="tab-content">
 <?php if(Session::has('Adminnewlogin')): ?><a class="btn btn-info" href="<?php echo e(url('add_post')); ?>">Add Post</a><?php endif; ?>
 <table class="table">
  <thead>
    <tr>
      <th >#</th>
      <th >Title</th>
      <th >Description</th>
      <th >Image</th>
      <th >Action</th>
    </tr>
  </thead>
  <?php if($post->count()>0): ?>
  <?php $i=0;?>
  <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php  $i++ ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($i); ?></th>
      <td><?php echo e($rows['title']); ?></td>
      <td><?php echo e($rows['description']); ?></td>
      <td><img src="<?php echo e(url('public/images/'.$rows['featured_image'])); ?>" height="50px" width="50px"></td>
      <td><?php if(Session::has('Adminnewlogin') || Session::has('Editorlogin')): ?><button class="btn btn-info editPost" data-id="<?php echo e($rows['id']); ?>" type="button">Edit</button> <?php endif; ?>
      	<?php if(Session::has('Adminnewlogin')): ?><button class="btn btn-danger deletepost" data-id="<?php echo e($rows['id']); ?>" type="button">Delete</button> <?php endif; ?>
      
<a class="btn btn-success"  href="<?php echo e(url('post-view/'.$rows['slug'])); ?>">View</a>

      </td>
    </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</table>
</div>

</section>

</div>
<style type="text/css">
	/* FONT */
@import  url("https://fonts.googleapis.com/css?family=Lato");


/* Main Tabs */

label {
  background-color: #00262f;
  color: #ffffff;
  display: inline-block;
  cursor: pointer;
  padding: 8px;
  font-size: 14px;
}

label:hover {
  background-color: #02404b;
}

label input:checked {
  background-color: red;
}

.tab-radio {
  display: none;
}


/* Tabs behaviour, hidden if not checked/clicked */
.sub-tab-content,
.tab-content {
  display: none;
}

.tab-radio:checked + .tab-content,
.tab-radio:checked + .sub-tab-content {
  display: block;
}

/* Tabs Content */
.tab-content {
  padding: 10px;
  background-color: #ffffff;
  border: 1px solid #ddd;
  box-shadow: 2px 10px 6px -3px rgba(0, 0, 0, 0.5);
}

/* General */

body {
  width: 90%;
  margin: 10px auto;
  background-color: #ecf0f1;
  font-family: Lato, sans-serif;
  letter-spacing: 1px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8authdemo\resources\views/dashbord.blade.php ENDPATH**/ ?>