
			 <form method="post" action="#" id="editcatid">
			     
			    <?php echo e(csrf_field()); ?>

			    <?php if(!empty($cat)): ?>
			    <input type="hidden" name="id" value="<?php echo e($cat['id']); ?>">
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Category name</label>
				  <div class="col-sm-9">
					<input type="text"  name="category_name" class="form-control" placeholder="Category Name" value="<?php echo e($cat['category_name']); ?>" id="edit_cat_name">
					<span style="color: red;"><?php echo e($errors->first('category_name')); ?></span>
				  </div>
				</div>
				 
				<?php endif; ?>
				
				<div class="form-group">
					  <button type="button" class="btn btn-primary shadow-primary px-5 editcategory" >Submit</button>
				</div>
			 </form>
			 
       <?php /**PATH C:\xampp\htdocs\laravel8authdemo\resources\views/category/show_cat.blade.php ENDPATH**/ ?>