<form method="post" action="#" id="editpostid">
			     <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<?php if(!empty($post)): ?>
			    <input type="hidden" name="id" value="<?php echo e($post['id']); ?>">
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Title</label>
				  <div class="col-sm-9">
					<input type="text" id="edit_title" name="edit_title" class="form-control" placeholder="Title" value="<?php echo e($post['title']); ?>">
					<span style="color: red;"><?php echo e($errors->first('edit_title')); ?></span>
				  </div>
				</div>
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Slug</label>
				  <div class="col-sm-9">
					<input type="text" id="edit_slug" name="edit_slug" class="form-control" placeholder="Slug Name" value="<?php echo e($post['slug']); ?>">
					<span style="color: red;"><?php echo e($errors->first('edit_slug')); ?></span>
				  </div>
				</div>
				<div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Description</label>
				  <div class="col-sm-9">
					<textarea type="text" id="edit_description" name="edit_description" class="form-control" placeholder="Description"><?php echo e($post['description']); ?></textarea>
					<span style="color: red;"><?php echo e($errors->first('edit_description')); ?></span>
				  </div>
				</div>
				<div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Featured Image</label>
				  <div class="col-sm-9">
					<input type="file" id="edit_image" name="edit_image" class="form-control" placeholder="">
					<span style="color: red;"><?php echo e($errors->first('edit_image')); ?></span>
					<img src="<?php echo e(url('public/images/'.$post['featured_image'])); ?>" height="50px" width="50px">
					<input type="hidden" name="img" value="<?php echo e($post['featured_image']); ?>">
				  </div>
				</div>
				<?php endif; ?>
				<div class="form-group">
					  <button type="button" class="btn btn-primary shadow-primary px-5 editpost" >Submit</button>
				</div>
			 </form><?php /**PATH C:\xampp\htdocs\laravel8authdemo\resources\views/post/show_post.blade.php ENDPATH**/ ?>