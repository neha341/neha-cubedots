

<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Login</h2>
  <?php if(session()->has('messagerror')): ?>
          <div class="alert alert-danger">
              <?php echo e(session()->get('messagerror')); ?>

          </div>
  <?php endif; ?>
  <form class="form" method="post" action="<?php echo e(url('login')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
      <label for="email">Email:</label>
       <input type="text" id="exampleInputUsername" class="form-control form-control-rounded" placeholder="Username" name="email">
          <span style="color: red;"><?php echo e($errors->first('email')); ?></span>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
       <input type="password" id="exampleInputPassword" class="form-control form-control-rounded" placeholder="Password" name="password">
          <span style="color: red;"><?php echo e($errors->first('password')); ?></span>
    </div>
    <div class="form-group">
      <label for="pwd">Select Type:</label>
      <select class="form-control" id="type" name="type">
        <option value="super_admin">Super Admin</option>
        <option value="editor">Editor</option>
        <option value="reader">Reader </option>
      </select>
       <span style="color: red;"><?php echo e($errors->first('type')); ?></span>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/login.blade.php ENDPATH**/ ?>