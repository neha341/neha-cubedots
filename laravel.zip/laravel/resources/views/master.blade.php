<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.css">
  
</head>
<body>

  @yield('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js"></script>
   <script>  var APP_URL = {!! json_encode(url('/')) !!}</script>
   <script type="text/javascript">
	$('body').on('click','.addcategory',function(){

        var title =document.getElementById('category_name').value;
        if(title.length==""){
        alert('Please Enter Category Name!')
        document.getElementById('category_name').value="";
        document.getElementById('category_name').focus();
        return false;
        }
        var pattern= /^[a-zA-Z ]{2,30}$/
        var kycname =pattern.test(document.getElementById("category_name").value);
        if(kycname==false)
        {
        alert("Please Enter Valid Name!");
        document.getElementById("category_name").focus();
        return false;
        } 
        
        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });
            var formData = new FormData($("#catid")[0]);
        $.ajax({

           type:'POST',

           url:'{{ url("add-cat-frm")}}',

           data: formData,
           cache:false,
           contentType: false,
           processData: false,
           dataType: "json",
            beforeSend: function() {
            $("#overlay").fadeIn(300);　
            },
           success:function(data){
               if(data.success==true){
                
                  alertify.success(data.message);
                   window.location.href = data.redirect;
                 
               }else{
                 alertify.error(data.message);
               }
              

           }

        }).done(function() {
          setTimeout(function(){
            $("#overlay").fadeOut(300);
          },500);
        }); 

});


$('body').on('click','.editcategorys',function(){
	var id=$(this).attr('data-id');
	 $.ajax({
           type: "POST",
           url: '{{ url("edit_cat")}}',
           data: { "_token": "{{ csrf_token() }}", "id": id}, 
           success: function(data)
           {
           	$('#editmodal').html(data);
            $('#showcatmodal').modal('show');   
           }
         });

});



$('body').on('click','.editcategory',function(){
	// var title =document.getElementById('edit_cat_name').value;
 //        if(title.length==""){
 //        alert('Please Enter Category Name!')
 //        document.getElementById('edit_cat_name').value="";
 //        document.getElementById('edit_cat_name').focus();
 //        return false;
 //        }
 //        var pattern= /^[a-zA-Z ]{2,30}$/
 //        var kycname =pattern.test(document.getElementById("edit_cat_name").value);
 //        if(kycname==false)
 //        {
 //        alert("Please Enter Valid Name!");
 //        document.getElementById("edit_cat_name").focus();
 //        return false;
 //        } 
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }

        });
         var formData = new FormData($("#editcatid")[0]);
        $.ajax({

           type:'POST',

           url:'{{ url("edit-cat-frm")}}',

           data: formData,
           cache:false,
           contentType: false,
           processData: false,
           dataType: "json",
           success:function(data){
               if(data.success==true){
                
                  alertify.success(data.message);
                   window.location.href = data.redirect;
                 
               }else{
                 alertify.error(data.message);
               }
              

           }

        })
});

$('body').on('click','.deletecat',function(){
	var id=$(this).attr('data-id');

        if(confirm("Are you sure you want to delete this Record?")){
            $.ajax({
                type: "POST",
                url: '{{ url("delete-cat")}}',
                data:  { "_token": "{{ csrf_token() }}", "id": id},
                success: function(data){  
                	if(data.success==true){
                
	                  alertify.success(data.message);
	                   window.location.href = data.redirect;
	                 
	               }else{
	                 alertify.error(data.message);
	               }
                } 
            });
        }
        return false;
})


$('body').on('click','.addpost',function(){
	   var title =document.getElementById('title').value;
        if(title.length==""){
        alert('Please Enter Title !')
        document.getElementById('title').value="";
        document.getElementById('title').focus();
        return false;
        }
        var pattern= /^[a-zA-Z ]{2,30}$/
        var kycname =pattern.test(document.getElementById("title").value);
        if(kycname==false)
        {
        alert("Please Enter Valid Name!");
        document.getElementById("title").focus();
        return false;
        } 
        var slug =document.getElementById('slug').value;
        if(slug.length==""){
        alert('Please Enter slug !')
        document.getElementById('slug').value="";
        document.getElementById('slug').focus();
        return false;
        }
      
         var start =document.getElementById('description').value;
        if(start.length==""){
        alert('Please Enter description!')
        document.getElementById('description').value="";
        document.getElementById('description').focus();
        return false;
        }
         var product_image = document.getElementById("image").value;
        var ext = product_image.split('.').pop().toLowerCase();
        if(product_image=="")
        {
        alert("Please Select  Image jpg,jpeg,png Format");
        document.getElementById("image").focus();
        return false;
        }
        else if(product_image!="") ['pdf','doc','docx','xls']
        {    
        if($.inArray(ext, ['png','jpg','jpeg']) == -1)
        {
        //$("#examInputFiles").val('');
        alert("Wrong File Format!..Please Select Right Format");
        document.getElementById("image").value='';
        document.getElementById("image").focus();
        return false;
        }
        }


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }

        });
         var formData = new FormData($("#postid")[0]);
        $.ajax({

           type:'POST',

           url:'{{ url("add-post-frm")}}',

           data: formData,
           cache:false,
           contentType: false,
           processData: false,
           dataType: "json",
           success:function(data){
               if(data.success==true){
                
                  alertify.success(data.message);
                   window.location.href = data.redirect;
                 
               }else{
                 alertify.error(data.message);
               }
              

           }

        })
})


$('body').on('click','.editPost',function(){
	var id=$(this).attr('data-id');
	 $.ajax({
           type: "POST",
           url: '{{ url("edit_post")}}',
           data: { "_token": "{{ csrf_token() }}", "id": id}, 
           success: function(data)
           {
           	$('#editpostmodal').html(data);
            $('#showpostmodal').modal('show');   
           }
         });

});


$('body').on('click','.editpost',function(){
	var title =document.getElementById('edit_title').value;
        if(title.length==""){
        alert('Please Enter Title !')
        document.getElementById('edit_title').value="";
        document.getElementById('edit_title').focus();
        return false;
        }
        var pattern= /^[a-zA-Z ]{2,30}$/
        var kycname =pattern.test(document.getElementById("edit_title").value);
        if(kycname==false)
        {
        alert("Please Enter Valid Name!");
        document.getElementById("edit_title").focus();
        return false;
        } 
        var slug =document.getElementById('edit_slug').value;
        if(slug.length==""){
        alert('Please Enter slug !')
        document.getElementById('edit_slug').value="";
        document.getElementById('edit_slug').focus();
        return false;
        }
       
         var start =document.getElementById('edit_description').value;
        if(start.length==""){
        alert('Please Enter description!')
        document.getElementById('edit_description').value="";
        document.getElementById('edit_description').focus();
        return false;
        }
         var product_image = document.getElementById("edit_image").value;
        var ext = product_image.split('.').pop().toLowerCase();
        if(product_image!="")
        {    
        if($.inArray(ext, ['png','jpg','jpeg']) == -1)
        {
        //$("#examInputFiles").val('');
        alert("Wrong File Format!..Please Select Right Format");
        document.getElementById("edit_image").value='';
        document.getElementById("edit_image").focus();
        return false;
        }
        }


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }

        });
         var formData = new FormData($("#editpostid")[0]);
        $.ajax({

           type:'POST',

           url:'{{ url("edit-post-frm")}}',

           data: formData,
           cache:false,
           contentType: false,
           processData: false,
           dataType: "json",
           success:function(data){
               if(data.success==true){
                
                  alertify.success(data.message);
                   window.location.href = data.redirect;
                 
               }else{
                 alertify.error(data.message);
               }
              

           }

        })
})


$('body').on('click','.deletepost',function(){
	var id=$(this).attr('data-id');

        if(confirm("Are you sure you want to delete this Record?")){
            $.ajax({
                type: "POST",
                url: '{{ url("delete-post")}}',
                data:  { "_token": "{{ csrf_token() }}", "id": id},
                success: function(data){  
                	if(data.success==true){
                
	                  alertify.success(data.message);
	                   window.location.href = data.redirect;
	                 
	               }else{
	                 alertify.error(data.message);
	               }
                } 
            });
        }
        return false;
})


$('body').on('change blur keyup','#title',function(){
    var menu=$(this).val();
    var menus=menu.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
    var result = menus.replace(/ /g, "");
  
    var number = 1 + Math.floor(Math.random() * 6)+result;
    $('#slug').val(number);
    
})
$('body').on('change blur keyup','#edit_title',function(){
    var menu=$(this).val();
    var menus=menu.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
    var result = menus.replace(/ /g, "");
  
    var number = 1 + Math.floor(Math.random() * 6)+result;
    $('#edit_slug').val(number);
    
})
</script>
</body>
</html>
<div class="modal fade" id="showcatmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Category</h4>
        </div>
        <div class="modal-body" id="editmodal">
      
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
 </div>


<div class="modal fade" id="showpostmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Post</h4>
        </div>
        <div class="modal-body" id="editpostmodal">
      
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
