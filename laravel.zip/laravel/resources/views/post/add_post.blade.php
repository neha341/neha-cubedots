@extends('master')

@section('content')

	
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
             <h1>Post</h1>
             <div class="card-body">
			  <a href="{{url('dashboard')}}" class="btn btn-primary">< Back</a>
			 <form method="post" action="#" id="postid">
			     <input type="hidden" name="_token" value="{{csrf_token()}}">

			
			    
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Title</label>
				  <div class="col-sm-9">
					<input type="text" id="title" name="title" class="form-control" placeholder="Title">
					<span style="color: red;">{{ $errors->first('title')}}</span>
				  </div>
				</div>
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Slug</label>
				  <div class="col-sm-9">
					<input type="text" id="slug" name="slug" class="form-control" placeholder="Enter Slug">
					<span style="color: red;">{{ $errors->first('slug')}}</span>
				  </div>
				</div>
				<div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Description</label>
				  <div class="col-sm-9">
					<input type="text" id="description" name="description" class="form-control" placeholder="Enter Description">
					<span style="color: red;">{{ $errors->first('description')}}</span>
				  </div>
				</div>
				<div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Featured Image</label>
				  <div class="col-sm-9">
					<input type="file" id="image" name="image" class="form-control" placeholder="">
					<span style="color: red;">{{ $errors->first('image')}}</span>
				  </div>
				</div>
				
				<div class="form-group">
					  <button type="button" class="btn btn-primary shadow-primary px-5 addpost" >Submit</button>
				</div>
			 </form>
			 
             </div>
          </div>
        </div>
      </div><!--End Row-->

	  
      
@endsection