@extends('master')
@section('content')




<div class="container">

   <a href="{{url('dashboard')}}" class="btn btn-primary">< Back</a>

 <table class="table">
  <thead>
    <tr>
      <th >#</th>
      <th >Title</th>
      <th>Slug</th>
      <th >Description</th>
      <th >Image</th>
    </tr>
  </thead>
  @if($post->count()>0)
  @php $i=0;@endphp
  @foreach($post as $rows)
  @php  $i++ @endphp
  <tbody>
    <tr>
      <th scope="row">{{$i}}</th>
      <td>{{$rows['title']}}</td>
      <td>{{$rows['slug']}}</td>
      <td>{{$rows['description']}}</td>
      <td><img src="{{url('public/images/'.$rows['featured_image'])}}" height="50px" width="50px"></td>
      

     
    </tr>
  </tbody>
  @endforeach
  @endif
</table>
</div>
<style type="text/css">
	/* FONT */
@import url("https://fonts.googleapis.com/css?family=Lato");


/* Main Tabs */

label {
  background-color: #00262f;
  color: #ffffff;
  display: inline-block;
  cursor: pointer;
  padding: 8px;
  font-size: 14px;
}

label:hover {
  background-color: #02404b;
}

label input:checked {
  background-color: red;
}

.tab-radio {
  display: none;
}


/* Tabs behaviour, hidden if not checked/clicked */
.sub-tab-content,
.tab-content {
  display: none;
}

.tab-radio:checked + .tab-content,
.tab-radio:checked + .sub-tab-content {
  display: block;
}

/* Tabs Content */
.tab-content {
  padding: 10px;
  background-color: #ffffff;
  border: 1px solid #ddd;
  box-shadow: 2px 10px 6px -3px rgba(0, 0, 0, 0.5);
}

/* General */

body {
  width: 90%;
  margin: 10px auto;
  background-color: #ecf0f1;
  font-family: Lato, sans-serif;
  letter-spacing: 1px;
}
</style>
@endsection