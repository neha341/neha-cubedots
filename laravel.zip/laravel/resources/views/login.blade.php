
@extends('master')
@section('content')
<div class="container">
  <h2>Login</h2>
  @if(session()->has('messagerror'))
          <div class="alert alert-danger">
              {{ session()->get('messagerror') }}
          </div>
  @endif
  <form class="form" method="post" action="{{ url('login') }}">
    {{ csrf_field() }}
    <div class="form-group">
      <label for="email">Email:</label>
       <input type="text" id="exampleInputUsername" class="form-control form-control-rounded" placeholder="Username" name="email">
          <span style="color: red;">{{ $errors->first('email')}}</span>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
       <input type="password" id="exampleInputPassword" class="form-control form-control-rounded" placeholder="Password" name="password">
          <span style="color: red;">{{ $errors->first('password')}}</span>
    </div>
    <div class="form-group">
      <label for="pwd">Select Type:</label>
      <select class="form-control" id="type" name="type">
        <option value="super_admin">Super Admin</option>
        <option value="editor">Editor</option>
        <option value="reader">Reader </option>
      </select>
       <span style="color: red;">{{ $errors->first('type')}}</span>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>
@endsection