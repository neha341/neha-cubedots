
			 <form method="post" action="#" id="editcatid">
			     
			    {{ csrf_field() }}
			    @if(!empty($cat))
			    <input type="hidden" name="id" value="{{$cat['id']}}">
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Category name</label>
				  <div class="col-sm-9">
					<input type="text"  name="category_name" class="form-control" placeholder="Category Name" value="{{$cat['category_name']}}" id="edit_cat_name">
					<span style="color: red;">{{ $errors->first('category_name')}}</span>
				  </div>
				</div>
				 
				@endif
				
				<div class="form-group">
					  <button type="button" class="btn btn-primary shadow-primary px-5 editcategory" >Submit</button>
				</div>
			 </form>
			 
       