@extends('master')

@section('content')

	
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
             <h1>Category</h1>
             <div class="card-body">
			 <a href="{{url('dashboard')}}" class="btn btn-primary">< Back</a>
			 <form method="post" action="#" id="catid">
			     <input type="hidden" name="_token" value="{{csrf_token()}}">
			
			    
				 <div class="form-group row">
				  <label for="basic-input" class="col-sm-3 col-form-label">Category name</label>
				  <div class="col-sm-9">
					<input type="text" id="category_name" name="category_name" class="form-control" placeholder="Category Name">
					<span style="color: red;">{{ $errors->first('category_name')}}</span>
				  </div>
				</div>
				 
				
				
				<div class="form-group">
					  <button type="button" class="btn btn-primary shadow-primary px-5 addcategory" >Submit</button>
				</div>
			 </form>
			 
             </div>
          </div>
        </div>
      </div><!--End Row-->

	  
      
@endsection