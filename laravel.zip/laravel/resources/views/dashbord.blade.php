@extends('master')
@section('content')




<div class="container">Welcom @if(Session::has('Adminnewlogin'))
<?php echo session('Adminnewlogin')['name']; ?>
@elseif(Session::has('Editorlogin'))
<?php echo session('Editorlogin')['name']; ?>
@elseif(Session::has('Readerlogin'))
<?php echo session('Readerlogin')['name']; ?>
@endif

 ,
<a href="{{ url('logout')}}"><i class="icon-power mr-2"></i> Logout</a>

<section>
<div class="top-tabs-container">
  <label for="main-tab-1">Category</label>
  <label for="main-tab-2">Post</label>

</div>

<!-- Tab Container -->
<input class="tab-radio" id="main-tab-1" name="main-group" type="radio" checked="checked"/>
<div class="tab-content">
	@if(Session::has('Adminnewlogin'))<a class="btn btn-info" href="{{url('add_category')}}">Add Category</a> @endif
  <table class="table">
  <thead>
    <tr>
      <th >#</th>
      <th >Category Name</th>
      <th >Created at</th>
      <th >Updated at</th>
      <th >Action</th>
    </tr>
  </thead>
  @if($cat->count()>0)
  @php $i=0;@endphp
  @foreach($cat as $rows)
  @php  $i++ @endphp
  <tbody>
    <tr>
      <th scope="row">{{$i}}</th>
      <td>{{$rows['category_name']}}</td>
      <td>{{$rows['created_at']}}</td>
      <td>{{$rows['updated_at']}}</td>
    
      <td>  @if(Session::has('Adminnewlogin') || Session::has('Editorlogin'))
      	<button class="btn btn-info editcategorys" data-id="{{$rows['id']}}" type="button">Edit</button>@endif
      	@if(Session::has('Adminnewlogin'))<button class="btn btn-danger deletecat" data-id="{{$rows['id']}}" type="button">Delete</button>@endif

      </td>



    </tr>
  </tbody>
  @endforeach
  @endif
</table>
</div>


<!-- EXTRA TABS FOR SHOW & TESTING -->
  
 <!-- Tab Container -->
<input class="tab-radio" id="main-tab-2" name="main-group" type="radio"/>
<div class="tab-content">
 @if(Session::has('Adminnewlogin'))<a class="btn btn-info" href="{{url('add_post')}}">Add Post</a>@endif
 <table class="table">
  <thead>
    <tr>
      <th >#</th>
      <th >Title</th>
      <th >Description</th>
      <th >Image</th>
      <th >Action</th>
    </tr>
  </thead>
  @if($post->count()>0)
  @php $i=0;@endphp
  @foreach($post as $rows)
  @php  $i++ @endphp
  <tbody>
    <tr>
      <th scope="row">{{$i}}</th>
      <td>{{$rows['title']}}</td>
      <td>{{$rows['description']}}</td>
      <td><img src="{{url('public/images/'.$rows['featured_image'])}}" height="50px" width="50px"></td>
      <td>@if(Session::has('Adminnewlogin') || Session::has('Editorlogin'))<button class="btn btn-info editPost" data-id="{{$rows['id']}}" type="button">Edit</button> @endif
      	@if(Session::has('Adminnewlogin'))<button class="btn btn-danger deletepost" data-id="{{$rows['id']}}" type="button">Delete</button> @endif
      
<a class="btn btn-success"  href="{{url('post-view/'.$rows['slug'])}}">View</a>

      </td>
    </tr>
  </tbody>
  @endforeach
  @endif
</table>
</div>

</section>

</div>
<style type="text/css">
	/* FONT */
@import url("https://fonts.googleapis.com/css?family=Lato");


/* Main Tabs */

label {
  background-color: #00262f;
  color: #ffffff;
  display: inline-block;
  cursor: pointer;
  padding: 8px;
  font-size: 14px;
}

label:hover {
  background-color: #02404b;
}

label input:checked {
  background-color: red;
}

.tab-radio {
  display: none;
}


/* Tabs behaviour, hidden if not checked/clicked */
.sub-tab-content,
.tab-content {
  display: none;
}

.tab-radio:checked + .tab-content,
.tab-radio:checked + .sub-tab-content {
  display: block;
}

/* Tabs Content */
.tab-content {
  padding: 10px;
  background-color: #ffffff;
  border: 1px solid #ddd;
  box-shadow: 2px 10px 6px -3px rgba(0, 0, 0, 0.5);
}

/* General */

body {
  width: 90%;
  margin: 10px auto;
  background-color: #ecf0f1;
  font-family: Lato, sans-serif;
  letter-spacing: 1px;
}
</style>
@endsection